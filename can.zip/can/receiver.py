# === Pico #2: Receiver (CAN 0x100 -> LED PWM on Pin27/GP21) ===
from machine import Pin, SPI, PWM
import utime

# ----- MCP2515 low-level -----
CMD_RESET=0xC0; CMD_READ=0x03; CMD_WRITE=0x02; CMD_BIT_MODIFY=0x05
CMD_READ_STATUS=0xA0; CMD_RX_STATUS=0xB0; CMD_READ_RX=0x90

REG_CANCTRL=0x0F; REG_CANSTAT=0x0E
REG_CNF1=0x2A; REG_CNF2=0x29; REG_CNF3=0x28
REG_CANINTF=0x2C; REG_RXB0CTRL=0x60; REG_RXB1CTRL=0x70

OPMODE_NORMAL=0x00; OPMODE_CONFIG=0x80

class MCP2515:
    def __init__(self, spi, cs, int_pin=None):
        self.spi=spi; self.cs=cs; self.cs.init(Pin.OUT, value=1); self.int_pin=int_pin
    def _cs_low(self): self.cs.value(0)
    def _cs_high(self): self.cs.value(1)
    def reset(self):
        self._cs_low(); self.spi.write(bytearray([CMD_RESET])); self._cs_high(); utime.sleep_ms(5)
    def write(self, reg, *vals):
        self._cs_low(); self.spi.write(bytearray([CMD_WRITE, reg]+list(vals))); self._cs_high()
    def read(self, reg, n=1):
        self._cs_low(); self.spi.write(bytearray([CMD_READ, reg])); d=self.spi.read(n); self._cs_high()
        return d if n>1 else d[0]
    def bit_modify(self, reg, mask, data):
        self._cs_low(); self.spi.write(bytearray([CMD_BIT_MODIFY, reg, mask, data])); self._cs_high()
    def set_opmode(self, mode):
        self.bit_modify(REG_CANCTRL, 0xE0, mode)
        for _ in range(50):
            if (self.read(REG_CANSTAT)&0xE0)==mode: return True
            utime.sleep_ms(1)
        return False
    def set_bitrate_500k_8mhz(self):
        # 500 kbps @ 8 MHz (CNF1, CNF2, CNF3)
        self.write(REG_CNF1, 0x00)
        self.write(REG_CNF2, 0x90)
        self.write(REG_CNF3, 0x02)
    def accept_all(self):
        self.write(REG_RXB0CTRL, 0b01100100)  # RXM=11, BUKT=1
        self.write(REG_RXB1CTRL, 0b01100000)  # RXM=11
        self.bit_modify(REG_CANINTF, 0x03, 0x00)
    def read_any(self):
        # Which RX buffer has data?
        self._cs_low(); self.spi.write(bytearray([CMD_READ_STATUS])); st=self.spi.read(1)[0]; self._cs_high()
        if st & 0x01:  sel=0x00  # RXB0
        elif st & 0x02: sel=0x04 # RXB1
        else: return None
        # Read chosen buffer
        self._cs_low(); self.spi.write(bytearray([CMD_READ_RX|sel])); rx=self.spi.read(13); self._cs_high()
        can_id=(rx[0]<<3)|(rx[1]>>5); dlc=rx[4]&0x0F; data=rx[5:5+dlc]
        # Clear proper RX flag
        self.bit_modify(REG_CANINTF, 0x01 if sel==0x00 else 0x02, 0x00)
        return can_id, data

# --- Your physical pins → GPIO ---
spi=SPI(0, baudrate=1_000_000, polarity=0, phase=0, sck=Pin(18), mosi=Pin(19), miso=Pin(16))
cs =Pin(17, Pin.OUT)   # CS  Pin22 -> GP17
intp=Pin(20, Pin.IN)   # INT Pin26 -> GP20

can=MCP2515(spi, cs, intp)
status_led=Pin(25, Pin.OUT)

# LED PWM on Pin27 -> GP21
led=PWM(Pin(21)); led.freq(1000)

# Blink at start
for _ in range(5): status_led.toggle(); utime.sleep_ms(120)
status_led.off()

# MCP2515 init (8 MHz)
can.reset()
can.set_opmode(OPMODE_CONFIG)
can.set_bitrate_500k_8mhz()
can.accept_all()
can.set_opmode(OPMODE_NORMAL)

print("Receiver ready (expect ID 0x100)")

while True:
    msg=can.read_any()
    if msg:
        can_id, data=msg
        if can_id==0x100 and len(data)>=1:
            b=data[0]               # 0..255
            led.duty_u16(b*257)     # scale to 0..65535
            print("RX:", b)
            status_led.toggle()
    utime.sleep_ms(1)
