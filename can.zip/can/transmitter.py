# === Pico #1: Sender (Potentiometer -> CAN 0x100, 1 byte) ===
from machine import Pin, SPI, ADC
import utime

# ----- MCP2515 low-level -----
CMD_RESET=0xC0; CMD_READ=0x03; CMD_WRITE=0x02; CMD_BIT_MODIFY=0x05
CMD_READ_STATUS=0xA0; CMD_RX_STATUS=0xB0; CMD_READ_RX=0x90; CMD_RTS=0x80

REG_CANCTRL=0x0F; REG_CANSTAT=0x0E
REG_CNF1=0x2A; REG_CNF2=0x29; REG_CNF3=0x28
REG_CANINTF=0x2C; REG_RXB0CTRL=0x60; REG_RXB1CTRL=0x70
REG_TXB0SIDH=0x31; REG_TXB0SIDL=0x32; REG_TXB0DLC=0x35; REG_TXB0D0=0x36

OPMODE_NORMAL=0x00; OPMODE_CONFIG=0x80

class MCP2515:
    def __init__(self, spi, cs, int_pin=None):
        self.spi=spi; self.cs=cs; self.cs.init(Pin.OUT, value=1); self.int_pin=int_pin
    def _cs_low(self): self.cs.value(0)
    def _cs_high(self): self.cs.value(1)
    def reset(self):
        self._cs_low(); self.spi.write(bytearray([CMD_RESET])); self._cs_high(); utime.sleep_ms(5)
    def write(self, reg, *vals):
        self._cs_low(); self.spi.write(bytearray([CMD_WRITE, reg]+list(vals))); self._cs_high()
    def read(self, reg, n=1):
        self._cs_low(); self.spi.write(bytearray([CMD_READ, reg])); d=self.spi.read(n); self._cs_high()
        return d if n>1 else d[0]
    def bit_modify(self, reg, mask, data):
        self._cs_low(); self.spi.write(bytearray([CMD_BIT_MODIFY, reg, mask, data])); self._cs_high()
    def set_opmode(self, mode):
        self.bit_modify(REG_CANCTRL, 0xE0, mode)
        for _ in range(50):
            if (self.read(REG_CANSTAT)&0xE0)==mode: return True
            utime.sleep_ms(1)
        return False
    def set_bitrate_500k_8mhz(self):
        # 500 kbps @ 8 MHz  (CNF1, CNF2, CNF3)
        self.write(REG_CNF1, 0x00)
        self.write(REG_CNF2, 0x90)  # BTLMODE=1, SAM=0, PHSEG1=2TQ, PRSEG=1TQ
        self.write(REG_CNF3, 0x02)  # PHSEG2=3TQ
    def accept_all(self):
        self.write(REG_RXB0CTRL, 0b01100100)  # RXM=11, BUKT=1
        self.write(REG_RXB1CTRL, 0b01100000)  # RXM=11
        self.bit_modify(REG_CANINTF, 0x03, 0x00)
    def send_std(self, can_id, data):
        sidh=(can_id>>3)&0xFF; sidl=(can_id<<5)&0xE0; dlc=len(data)&0x0F
        self._cs_low()
        self.spi.write(bytearray([CMD_WRITE, REG_TXB0SIDH, sidh, sidl, 0x00, 0x00, dlc]))
        if dlc: self.spi.write(bytes(data))
        self._cs_high()
        self._cs_low(); self.spi.write(bytearray([CMD_RTS|0x01])); self._cs_high()

# --- Your physical pins → GPIO ---
# SPI0: SCK=GP18 (Pin24), MOSI=GP19 (Pin25), MISO=GP16 (Pin21)
spi=SPI(0, baudrate=1_000_000, polarity=0, phase=0, sck=Pin(18), mosi=Pin(19), miso=Pin(16))
cs =Pin(17, Pin.OUT)   # CS  Pin22 -> GP17
intp=Pin(20, Pin.IN)   # INT Pin26 -> GP20 (optional)

can=MCP2515(spi, cs, intp)
status_led=Pin(25, Pin.OUT)

# Blink at start
for _ in range(5): status_led.toggle(); utime.sleep_ms(120)
status_led.off()

# MCP2515 init (8 MHz)
can.reset()
can.set_opmode(OPMODE_CONFIG)
can.set_bitrate_500k_8mhz()
can.accept_all()
can.set_opmode(OPMODE_NORMAL)

# Pot on Pin31 -> GP26/ADC0
pot=ADC(26)

while True:
    raw=pot.read_u16()            # 0..65535
    brightness=raw>>8             # 0..255
    can.send_std(0x100, bytearray([brightness]))
    print("TX:", brightness)
    status_led.toggle()
    utime.sleep_ms(100)
